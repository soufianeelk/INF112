/**
 * Tests for the SocialNetwork
 */

package tests;