/**
 * Components for a simple Human-Machine Interface
 */
package hmi;
