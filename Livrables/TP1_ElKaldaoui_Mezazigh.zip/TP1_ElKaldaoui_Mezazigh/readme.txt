Dépot TP1 itération 1 réalisé par EL KALDAOUI Soufiane et MEZAZIGH Hishame dans le cadre du projet INF112. Il contient:

	- Diagramme de Classe mis à jour correspondant au lot 1
	- Diagrammes de séquence complets (cas nominaux et levées des exceptions) et actualisés d’addMember(), addItemlFilm() et reviewItemFilm()
	- Un code Java incomplet correspondant à ces diagrammes
	- Une trace d’exécution des tests de d’addMember(), addItemlFilm() et reviewItemFilm()