package tests;
import exceptions.BadEntryException;
import exceptions.MemberAlreadyExistsException;
import exceptions.NotMemberException;
import opinion.ISocialNetwork;
import opinion.SocialNetwork;

public class AuthenticateMemberTest {
	
	/*public boolean addMemberOKtest(SocialNetwork sn, login, password) {
		if (this.authenticateMember("login", "password") != null) return 1;
	}
	
	public static void main(String[] args) {
		
	int nbTests = 0;
	int nbErrors = 0;
	
	SocialNetwork sn = new SocialNetwork();
	
	System.out.println("Testing authenticateMemberTest()");
	
	//Creating a new Member
	try {
		sn.addMember("login", "password", "profile");
	} catch (BadEntryException | MemberAlreadyExistsException e1) {
		e1.printStackTrace();
	}
	
	//Trying to authenticate with right credentials


	
	try {
		sn.authenticateMember("login", "password");
	} catch (NotMemberException e) {
		e.printStackTrace();
	}
	
	
	
	}*/
}
