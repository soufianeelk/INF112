Dépot TP2 réalisé par EL KALDAOUI Soufiane et MEZAZIGH Hishame dans le cadre du projet INF112. Il contient:

	- Code Java de notre lot 1 (Classe Social Network)
	- Code Java de nos tests lot 1
	- Une trace d’exécution de nos tests
	- Fichier src contenant tout le projet