Dépot BE2 réalisé par EL KALDAOUI Soufiane et MEZAZIGH Hishame dans le cadre du projet INF112. Il contient:

	- La Classe AddItemFilmTest
	- La fiche de validation de test avec la partie Test complétée
	- Une capture de l'execution de la classe remontant toutes les erreurs