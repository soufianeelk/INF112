/**
 * Classes containing all the classes used to perform tests on the social network method. 
 * 
 * @since 1.0
 * @author Hishame MEZAZIGH/Soufiane EL KALADOUI
 * @version 1.0
 */

package tests;