/**
 * Classes containing all the classes used to constitute the social network objects. 
 * <p>
 * These classes contain the following classes :
 * 
 * 		- Book,Film,HMI,ISocialNetwork,Member,Review, SocialNetwork
 *</p>
 *
 * @since 1.0
 * @author Hishame MEZAZIGH/Soufiane EL KALADOUI
 * @version 1.0
 */
package opinion;