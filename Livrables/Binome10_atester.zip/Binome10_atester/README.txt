D�pot TP1 it�ration 1 r�alis� par EL KALDAOUI Soufiane et MEZAZIGH Hishame dans le cadre du projet INF112. Il contient:

   

LOT 1 + TESTS: 
 - Diagramme de Classe mis � jour correspondant au lot 1
   
 - Diagrammes de s�quence complets (cas nominaux et lev�es des exceptions) et actualis�s d�addMember(), addItemlFilm() et reviewItemFilm()
   
 - Un code Java complet correspondant � ces diagrammes
    
  - Une trace d�ex�cution des tests de d�addMember(), addItemlFilm() et reviewItemFilm()

LOT 2 + TESTS: 

 - Diagramme de Classe correspondant au lot 2
 - Un premier esquisse du diagramme de s�quence de reviewOpinion() pour le cas nominal
 - Un code Java incomplet correspondant au lot2. 
 - Une trace d'execution du test du lot2 (java test2.SocialNetworkTest)