Dépot BE3 première itération réalisé par EL KALDAOUI Soufiane et MEZAZIGH Hishame dans le cadre du projet INF112. Il contient:

	- Diagramme de séquence dans le cas normal
	- Diagramme de séquence dans le cas de paramètres incorrects
	- Diagramme de séquence dans le cas d'un login existant