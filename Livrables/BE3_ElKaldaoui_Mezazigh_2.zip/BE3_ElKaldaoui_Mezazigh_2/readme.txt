Dépot BE3 deuxième itération réalisé par EL KALDAOUI Soufiane et MEZAZIGH Hishame dans le cadre du projet INF112. Il contient:
	
	- Diagramme de Classe relatif à la gestion des membres et gestion de films
	- Diagramme de séquence reviewItemFilm de cas nominal