
class Film {
  private String title;

  private String kind;

  private String director;

  private String scriptwriter;

  private int duration;

  public  Film(String title, String kind, String director, String scriptwriter, int duration) {
  }

  public String getTitle() {
  }

  public String getKind() {
  }

  public String getDirector() {
  }

  public String getScriptwriter() {
  }

  public int getDuration() {
  }

  public  setKind(String kind) {
  }

  public  setDirector(String director) {
  }

  public  setScriptwriter(String scriptwriter) {
  }

  public  setDuration(int duration) {
  }

  private float meanReviews;

  private int nbReviews;

  private <Review> reviewsList;

  public float getMeanReviews() {
  }

  public Film searchTitle(String title) {
  }

  public  setReview(String comment, int mark) {
  }

  public boolean checkExistingTitle() {
  }

  public boolean checkMemberReviewExisting() {
  }

}
