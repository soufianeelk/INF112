
class Member {
  public Member(String login, String password) {
  }

  public Member(String login, String password, String profile) {
  }

  private String login;

  private String password;

  private String profile;

  public boolean checkExistingLogin(String login) {
  }

  public boolean checkCredentials() {
  }

  public String getProfile() {
  }

  public void setProfile(String profile) {
  }

  public void setLogin(String login) {
  }

  public Review getReviews() {
  }

}
