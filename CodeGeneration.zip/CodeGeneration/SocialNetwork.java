
class SocialNetwork extends Member {
  public SocialNetwork() {
  }

  public int nbMembers() {
  }

  public int nbFilms() {
  }

  public void addMember(String login, String password, profile String) {
  }

  public String toString() {
  }

  public  addItemFilm(String login, String password, String title, String kind, String director, String scriptwriter, int duration) {
  }

  public float reviewItemFilm(String login, String password, String title, float mark, String comment) {
  }

  private <Member> membersList;

  private int nbMembers;

  private int nbFilms;

  public <Film> filmsList;

}
