
class Review {
  private String comment;

  private int mark;

  public Review(int mark, String comment) {
  }

  public  Review(int mark) {
  }

  public String getComment( ) {
  }

  public int getMark( ) {
  }

  public  setComment( String) {
  }

  public  setMark(int mark) {
  }

  private Member member;

  public Member getMember() {
  }

  private Film ;

}
